#include <iostream>

using namespace std;

int main() {
    int a = -1;

    cout<<"Ingrese un número positivo, menor a 128." <<endl;

    for(int i=0; i<a; i++){
        cout<<"Contando números: "<<i<<endl;
    }
    return 0;
}